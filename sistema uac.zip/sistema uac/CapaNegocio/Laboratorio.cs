﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Laboratorio
    {
        // atributos
        private string curso;
        private string nombre;
        private int aforo;
        // propiedades
        public string Curso
        {
            get { return curso; }
            set { curso = value; }
        }
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public int Aforo
        {
            get { return aforo; }
            set { aforo = value; }
        }
        // metodos
        public string Trabajar()
        {
            return "no se ha implementado el metodo trabajar";
        }
        public string Apender()
        {
            return "no se ha implementado el metodo aprender";
        }


    }
}
