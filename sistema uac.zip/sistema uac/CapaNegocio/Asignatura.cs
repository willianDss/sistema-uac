﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Asignatura
    {
        // atributos
        private string nombre;
        private int hora;
        private string docente;

        // propiedades
        public string Nombre
        {
            get { return nombre; } 
            set { nombre = value; } 
        }
        public int Hora
        {
            get { return hora; }
            set { hora = value; }
        }
        public string Docente
        {
            get { return docente; }
            set { docente = value; }
        }
        // metodos
        public string Estudiar()
        {
            return "no se ha implementado el metodo estudiar";
        }
        public string Aprobar()
        {
            return "no se ha implementado el metodo aprobar";
        }
    }
}
