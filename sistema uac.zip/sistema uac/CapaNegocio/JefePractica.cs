﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class JefePractica
    {
        // atributos
        private string apellidos;
        private string nombre;
        private string lugarNacimiento;
        private int edad;
        private int dni;
        // propiedades
        public string Apellidos
        {
            get { return apellidos; } 
            set { apellidos = value; } 
        }
        public string Nombres
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }
        public string LugarNacimiento
        {
            get { return this.lugarNacimiento; }
            set { this.lugarNacimiento = value; }
        }
        public int Dni
        {
            get { return dni; }
            set { dni = value; }
        }
        // metodos
        public string Trabajar()
        {
            return "no se ha implementado el metodo trabajar";
        }
        public string Calificar()
        {
            return "no se ha implementado el metodo aprobar calificar";
        }
    }
}
