﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Notas
    {
        // atributos
        private string curso;
        private string alumno;
        private string conducta;
        //propiedades
        public string Curso
        {
            get { return curso; }
            set { curso = value; }
        }
        public string Alumno
        {
            get { return alumno; }
            set { alumno = value; }
        }
        public string Conducta
        {
            get { return conducta; }
            set { conducta = value; }
        }
        // metodos
        public string Estudiar()
        {
            return "no se ha implementado el metodo estudiar";
        }
        public string Aprobar()
        {
            return "no se ha implementado el metodo aprobar";
        }
        public string Desaprobar()
        {
            return "no se ha implementado el metodo desaprobar";
        }
    }
}
