﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class PPP
    {
        // atributos
        private string apellidos;
        private string nombres;
        private int edad;
        private int semestre;
        // propiedades
        public string Apellidos
        {
            get { return apellidos; }
            set { apellidos = value; }
        }
        public string Nombres
        {
            get { return nombres; }
            set { nombres = value; }
        }
        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }
        public int Semestre
        {
            get { return semestre; }
            set { semestre = value; }
        }
        // metodos
        public string Trabajar()
        {
            return "no se ha implementado el metodo trabajar";
        }
        public string ObtenerExperiencia()
        {
            return "no se ha implementado el metodo obtener experencia";
        }
    }
}
