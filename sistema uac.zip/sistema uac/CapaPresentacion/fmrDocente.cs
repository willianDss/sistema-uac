﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class fmrDocente : Form
    {
        public fmrDocente()
        {
            InitializeComponent();
        }
        CapaNegocio.Docente docente1 = new CapaNegocio.Docente();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            int edad = int.Parse(txtEdad.Text);
            string lugarNacimiento = txtLugarNacimiento.Text;
            docente1.Apellidos = apellidos;
            docente1.Nombres = nombres;
            docente1.Edad = edad;
            docente1.LugarNacimiento = lugarNacimiento;
            MessageBox.Show("se han registrado correctamente los datos de docente 1");
        }

        private void btnEscribir_Click(object sender, EventArgs e)
        {
            string apellidos = docente1.Apellidos;
            string nombres = docente1.Nombres;
            int edad = docente1.Edad;
            string lugarNacimiento = docente1.LugarNacimiento;
            MessageBox.Show("Apellidos:" + apellidos + "Nombres: " + nombres + "Edad: " + edad + "Lugar Nacimiento: " + lugarNacimiento);
        }

        private void btnEnseñar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(docente1.Enseñar());
        }

        private void btnTrabajar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(docente1.Trabajar());
        }

        private void btnCalificar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(docente1.Calificar());
        }
    }
}
