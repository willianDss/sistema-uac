﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class fmrAsignatura : Form
    {
        public fmrAsignatura()
        {
            InitializeComponent();
        }
        CapaNegocio.Asignatura asignatura1 = new CapaNegocio.Asignatura();
        private void btnLeer_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            int hora = int.Parse(txtHora.Text);
            string docente = txtDocente.Text;
            asignatura1.Nombre = nombre;
            asignatura1.Hora = hora;
            asignatura1.Docente = docente;
            MessageBox.Show("se han registrado correctamente los datos de asignatura 1");
        }

        private void btnEscribir_Click(object sender, EventArgs e)
        {
            string nombre = asignatura1.Nombre;
            int hora = asignatura1.Hora;
            string docente = asignatura1.Docente;
            MessageBox.Show("Nombre:" + nombre + "Hora: " + hora + "Docente: " + docente);
        }

        private void btnEstudiar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(asignatura1.Estudiar());
        }

        private void btnAprobar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(asignatura1.Aprobar());
        }
    }
}
